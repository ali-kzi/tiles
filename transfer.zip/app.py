from flask import Flask, Response, abort, render_template
import pymbtiles


app = Flask(__name__)

def xyz_to_tms(zoom, xtile, ytile_xyz):
    n = 1 << zoom
    ytile_tms = (n - 1) - ytile_xyz
    return xtile, ytile_tms

@app.route('/')
def index():
    return render_template("netsangonline.html")

@app.route('/<int:zoom>/<int:column>/<int:row>.pbf')
def serve_tile(zoom, column, row):
    column, row = xyz_to_tms(zoom, column, row)
    with pymbtiles.MBtiles("rsrp_avg.mbtiles") as src:
        tile_data = src.read_tile(zoom, column, row)
    
    if tile_data is None:
        abort(404)
    
    response = Response(tile_data, mimetype='application/x-protobuf')
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Connection'] = 'keep-alive'
    response.headers['Content-Encoding'] = 'gzip'
    response.headers['Content-Type'] = 'application/x-protobuf'
    return response

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
